package cl.spacedev.command.Spawn;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.Location;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class SpawnCommand implements CommandExecutor {
    private final JavaPlugin plugin;

    public SpawnCommand(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (sender instanceof Player) {
            Player player = (Player) sender;

            // Obtener la ubicación guardada del punto de aparición desde el archivo config.yml
            String worldName = plugin.getConfig().getString("spawn.world");
            double x = plugin.getConfig().getDouble("spawn.x");
            double y = plugin.getConfig().getDouble("spawn.y");
            double z = plugin.getConfig().getDouble("spawn.z");
            float yaw = (float) plugin.getConfig().getDouble("spawn.yaw");
            float pitch = (float) plugin.getConfig().getDouble("spawn.pitch");

            if (worldName != null && !worldName.isEmpty()) {
                // Teletransportar al jugador a la ubicación del punto de aparición
                Location location = new Location(plugin.getServer().getWorld(worldName), x, y, z, yaw, pitch);
                player.teleport(location);
                player.sendMessage("§2§lSPAWN » §fTeletransportado al punto de aparición.");
            } else {
                player.sendMessage("§2§lSPAWN » §fEl punto de aparición no está configurado correctamente.");
            }
        } else {
            sender.sendMessage("§2§lSPAWN » §fEste comando solo puede ser ejecutado por un jugador.");
        }

        return true;
    }
}

