package cl.spacedev.command.Spawn;

import cl.spacedev.SunUtils;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.Location;
public class JoinSpawn implements Listener {
    private SunUtils plugin;

    public JoinSpawn(SunUtils plugin) {
        this.plugin = plugin;
    }


    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();


        // Obtener la ubicación guardada del punto de aparición desde el archivo config.yml
        String worldName = plugin.getConfig().getString("spawn.world");
        double x = plugin.getConfig().getDouble("spawn.x");
        double y = plugin.getConfig().getDouble("spawn.y");
        double z = plugin.getConfig().getDouble("spawn.z");
        float yaw = (float) plugin.getConfig().getDouble("spawn.yaw");
        float pitch = (float) plugin.getConfig().getDouble("spawn.pitch");

        if (worldName != null && !worldName.isEmpty()) {
            // Teletransportar al jugador a la ubicación del punto de aparición
            Location location = new Location(plugin.getServer().getWorld(worldName), x, y, z, yaw, pitch);
            player.teleport(location);
        }
    }
}
