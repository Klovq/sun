package cl.spacedev.command;

import cl.spacedev.SunUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
public class CraftCommand implements CommandExecutor {

    private SunUtils plugin;

    public CraftCommand(SunUtils plugin) {
        this.plugin = plugin;
    }
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Este comando solo puede ser ejecutado por un jugador.");
            return true;
        }

        Player player = (Player) sender;
        player.openWorkbench(player.getLocation(), true);

        return true;
    }

}