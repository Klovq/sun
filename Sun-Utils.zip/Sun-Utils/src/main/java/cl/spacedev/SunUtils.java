package cl.spacedev;


import cl.spacedev.command.AnvilCommand;
import cl.spacedev.command.CraftCommand;
import cl.spacedev.command.EnderChestCommand;
import cl.spacedev.command.Spawn.JoinSpawn;
import cl.spacedev.command.Spawn.SetSpawnCommand;
import cl.spacedev.command.Spawn.SpawnCommand;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Objects;

public class SunUtils extends JavaPlugin {

    // Método que se ejecuta cuando se habilita el plugin
    @Override
    public void onEnable() {
        // Aquí puedes agregar el código que deseas ejecutar al habilitar el plugin
        getLogger().info("¡TuPlugin ha sido habilitado!");
        PluginManager pluginManager = getServer().getPluginManager();
        pluginManager.registerEvents(new JoinSpawn(this), this);
        registerCommand();
    }

    // Método que se ejecuta cuando se deshabilita el plugin
    @Override
    public void onDisable() {
        // Aquí puedes agregar el código que deseas ejecutar al deshabilitar el plugin
        getLogger().info("¡TuPlugin ha sido deshabilitado!");
    }
    public void registerCommand(){
        Objects.requireNonNull(this.getCommand("craft")).setExecutor(new CraftCommand(this));;
        Objects.requireNonNull(this.getCommand("ec")).setExecutor(new EnderChestCommand(this));;
        Objects.requireNonNull(this.getCommand("anvil")).setExecutor(new AnvilCommand(this));;
        Objects.requireNonNull(this.getCommand("setspawn")).setExecutor(new SetSpawnCommand(this));
        Objects.requireNonNull(this.getCommand("spawn")).setExecutor(new SpawnCommand(this));
    }
}